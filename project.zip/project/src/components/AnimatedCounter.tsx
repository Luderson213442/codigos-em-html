import React from 'react';
import { motion, useSpring, useTransform } from 'framer-motion';

interface AnimatedCounterProps {
  value: number;
  className?: string;
}

export function AnimatedCounter({ value, className = '' }: AnimatedCounterProps) {
  const spring = useSpring(0, {
    stiffness: 80,
    damping: 20,
    duration: 1.5
  });

  const display = useTransform(spring, (current) => Math.floor(current).toLocaleString());

  React.useEffect(() => {
    spring.set(value);
  }, [value, spring]);

  return (
    <motion.span className={className}>
      {display}
    </motion.span>
  );
}