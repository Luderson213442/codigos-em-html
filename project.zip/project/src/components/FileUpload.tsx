import React, { useCallback, useState } from 'react';
import { motion } from 'framer-motion';
import { Upload, AlertCircle, FileSpreadsheet, FileUp, Users, Link } from 'lucide-react';
import Papa from 'papaparse';
import { LeadData, UserProfile } from '../types';
import { parseISO, isValid } from 'date-fns';
import * as Dialog from '@radix-ui/react-dialog';
import * as Tabs from '@radix-ui/react-tabs';
import * as XLSX from 'xlsx';

interface FileUploadProps {
  onUpload: (data: LeadData[], sheetInfo?: { id: string; sheet: string }) => void;
  onUserProfilesUpload: (data: UserProfile[]) => void;
}

const DEFAULT_SHEET_URL = 'https://docs.google.com/spreadsheets/d/1lqhdwFNZABOYjLm2UPPtYGcVYDEIz4NpvgcxpMA4PqQ/edit?usp=sharing';

const CAMPOS = {
  'Nome': 'nome',
  'WhatsApp': 'whatsapp',
  'E-mail': 'email',
  'Nome da Empresa': 'empresa',
  'Faturamento em 2024': 'faturamento',
  'Cargo na Empresa': 'cargo',
  'Porque você deveria ser escolhido': 'motivo',
  'Data e Hora': 'dataHora',
  'Origem do Lead': 'origem',
  'Tags': 'tags'
};

const USER_CAMPOS = {
  'User': 'user',
  'E-mail': 'email',
  'Senha': 'senha',
  'Links': 'links'
};

const determinarQualidade = (tags: string[]): 'Alta' | 'Média' | 'Baixa' => {
  if (tags.includes('lead_alta_qualidade')) return 'Alta';
  if (tags.includes('lead_media_qualidade')) return 'Média';
  if (tags.includes('lead_baixa_qualidade')) return 'Baixa';
  return 'Média';
};

const parseDate = (dateStr: string): string => {
  if (!dateStr) return new Date().toISOString();
  
  try {
    let date = parseISO(dateStr);
    
    if (!isValid(date)) {
      // Try DD/MM/YYYY HH:mm:ss format
      const parts = dateStr.split(' ');
      if (parts.length === 2) {
        const [datePart, timePart] = parts;
        const [day, month, year] = datePart.split('/').map(Number);
        const [hours, minutes, seconds = 0] = timePart.split(':').map(Number);
        
        date = new Date(year, month - 1, day, hours, minutes, seconds);
      }
    }

    // If still not valid, try Excel date number
    if (!isValid(date)) {
      const excelDate = XLSX.SSF.parse_date_code(Number(dateStr));
      if (excelDate) {
        date = new Date(excelDate.y, excelDate.m - 1, excelDate.d, excelDate.H, excelDate.M, excelDate.S);
      }
    }

    if (!isValid(date)) {
      date = new Date();
    }

    return date.toISOString();
  } catch {
    return new Date().toISOString();
  }
};

export const processData = (rawData: any[]): LeadData[] => {
  return rawData.map((row: any) => {
    const csvTags = (row['Tags'] || '')
      .toString()
      .split(',')
      .map((tag: string) => tag.trim())
      .filter(Boolean);

    const qualidade = determinarQualidade(csvTags);
    const dataHora = parseDate(row['Data e Hora'] || '');

    return {
      id: crypto.randomUUID(),
      nome: (row['Nome'] || '').toString(),
      whatsapp: (row['WhatsApp'] || '').toString(),
      email: (row['E-mail'] || '').toString(),
      empresa: (row['Nome da Empresa'] || '').toString(),
      faturamento: (row['Faturamento em 2024'] || '').toString(),
      cargo: (row['Cargo na Empresa'] || '').toString(),
      motivo: (row['Porque você deveria ser escolhido'] || '').toString(),
      qualidade,
      dataHora,
      origem: (row['Origem do Lead'] || '').toString(),
      tags: csvTags
    };
  });
};

const processUserData = (rawData: any[]): UserProfile[] => {
  return rawData.map((row: any) => ({
    user: (row['User'] || '').toString(),
    email: (row['E-mail'] || '').toString(),
    senha: (row['Senha'] || '').toString(),
    links: (row['Links'] || '').toString().split(',').map(link => link.trim()).filter(Boolean)
  }));
};

export function FileUpload({ onUpload, onUserProfilesUpload }: FileUploadProps) {
  const [error, setError] = useState<string>('');
  const [sheetUrl, setSheetUrl] = useState('');
  const [isSheetModalOpen, setIsSheetModalOpen] = useState(false);
  const [workbook, setWorkbook] = useState<XLSX.WorkBook | null>(null);
  const [selectedSheet, setSelectedSheet] = useState('');
  const [sheets, setSheets] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [sheetId, setSheetId] = useState('');
  const [step, setStep] = useState<'users' | 'leads'>('users');

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setError('');
    const file = e.dataTransfer.files[0];
    if (file) {
      if (!file.name.endsWith('.csv')) {
        setError('Por favor, faça upload de um arquivo CSV');
        return;
      }
      readCSV(file);
    }
  }, [onUpload]);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    setError('');
    const file = e.target.files?.[0];
    if (file) {
      if (!file.name.endsWith('.csv')) {
        setError('Por favor, faça upload de um arquivo CSV');
        return;
      }
      readCSV(file);
    }
  }, [onUpload]);

  const readCSV = (file: File) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        try {
          if (results.errors.length > 0) {
            setError('Erro ao processar o arquivo CSV. Verifique o formato do arquivo.');
            return;
          }

          if (step === 'users') {
            const processedData = processUserData(results.data);
            onUserProfilesUpload(processedData);
            setStep('leads');
          } else {
            const processedData = processData(results.data);
            onUpload(processedData);
          }
        } catch (err) {
          setError('Erro ao processar o arquivo CSV');
        }
      },
      error: (error) => {
        setError(`Erro ao ler o arquivo: ${error.message}`);
      },
    });
  };

  const fetchSheetData = async (url: string = sheetUrl) => {
    try {
      setIsLoading(true);
      setError('');

      if (!url.includes('/spreadsheets/d/')) {
        throw new Error('URL inválida. Por favor, insira uma URL válida do Google Sheets.');
      }

      const matches = url.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
      if (!matches) {
        throw new Error('URL inválida. Não foi possível encontrar o ID da planilha.');
      }

      const id = matches[1];
      setSheetId(id);
      const exportUrl = `https://docs.google.com/spreadsheets/d/${id}/export?format=xlsx`;

      const response = await fetch(exportUrl);
      if (!response.ok) {
        throw new Error('Não foi possível acessar a planilha. Verifique se ela está pública.');
      }

      const arrayBuffer = await response.arrayBuffer();
      const wb = XLSX.read(arrayBuffer, { type: 'array' });
      
      if (wb.SheetNames.length === 1) {
        // If there's only one sheet, use it directly
        handleSheetSelect(wb.SheetNames[0], wb);
        return;
      }

      setWorkbook(wb);
      setSheets(wb.SheetNames);
      setSelectedSheet(wb.SheetNames[0]);
      setIsSheetModalOpen(true);
    } catch (err: any) {
      setError(err.message || 'Erro ao carregar a planilha');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSheetSelect = (sheetName: string, wb: XLSX.WorkBook | null = workbook) => {
    try {
      if (!wb) {
        throw new Error('Workbook não encontrado');
      }

      const sheet = wb.Sheets[sheetName];
      
      const jsonData = XLSX.utils.sheet_to_json(sheet, {
        header: 1,
        blankrows: false,
        raw: false,
        defval: ''
      });

      if (jsonData.length < 2) {
        throw new Error('A planilha está vazia ou não contém dados suficientes');
      }

      const headers = jsonData[0] as string[];
      const data = jsonData.slice(1).map(row => {
        const obj: any = {};
        headers.forEach((header, index) => {
          obj[header] = (row as any[])[index] || '';
        });
        return obj;
      });

      if (step === 'users') {
        const processedData = processUserData(data);
        onUserProfilesUpload(processedData);
        setStep('leads');
      } else {
        const processedData = processData(data);
        onUpload(processedData, { id: sheetId, sheet: sheetName });
      }

      setIsSheetModalOpen(false);
      setWorkbook(null);
      setSheets([]);
      setSelectedSheet('');
      setSheetUrl('');
    } catch (err: any) {
      setError(err.message || 'Erro ao processar a planilha selecionada');
    }
  };

  return (
    <motion.div
      className="flex flex-col items-center justify-center min-h-[70vh]"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="w-full max-w-2xl mb-8">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold flex items-center gap-2">
            {step === 'users' ? (
              <>
                <Users className="w-6 h-6 text-neon-purple" />
                Importar Perfis de Usuário
              </>
            ) : (
              <>
                <Upload className="w-6 h-6 text-neon-purple" />
                Importar Leads
              </>
            )}
          </h2>
          {step === 'leads' && (
            <button
              onClick={() => setStep('users')}
              className="text-sm text-neon-blue hover:underline"
            >
              Voltar para Importação de Usuários
            </button>
          )}
        </div>
        <p className="text-muted-foreground mt-2">
          {step === 'users'
            ? 'Primeiro, importe a planilha com os perfis de usuário'
            : 'Agora, importe a planilha com os leads'}
        </p>
      </div>

      <div className="w-full max-w-2xl mb-8">
        <button
          onClick={() => fetchSheetData(DEFAULT_SHEET_URL)}
          className="w-full p-4 bg-neon-blue/10 border-2 border-neon-blue rounded-lg hover:bg-neon-blue/20 transition-colors flex items-center justify-between group"
        >
          <div className="flex items-center gap-3">
            <Link className="w-5 h-5 text-neon-blue" />
            <div className="text-left">
              <p className="font-medium text-neon-blue">Utilizar dados base</p>
              <p className="text-sm text-muted-foreground truncate mt-1 max-w-[500px]">
                {DEFAULT_SHEET_URL}
              </p>
            </div>
          </div>
          <div className="opacity-0 group-hover:opacity-100 transition-opacity">
            <FileSpreadsheet className="w-5 h-5 text-neon-blue" />
          </div>
        </button>
        <div className="relative my-8">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-border"></div>
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-background px-2 text-muted-foreground">ou</span>
          </div>
        </div>
      </div>

      <Tabs.Root defaultValue="csv" className="w-full max-w-2xl">
        <Tabs.List className="flex space-x-2 mb-4">
          <Tabs.Trigger
            value="csv"
            className="flex items-center gap-2 px-4 py-2 rounded-md data-[state=active]:bg-secondary data-[state=active]:text-foreground"
          >
            <FileUp className="w-4 h-4" />
            Upload CSV
          </Tabs.Trigger>
          <Tabs.Trigger
            value="sheets"
            className="flex items-center gap-2 px-4 py-2 rounded-md data-[state=active]:bg-secondary data-[state=active]:text-foreground"
          >
            <FileSpreadsheet className="w-4 h-4" />
            Google Sheets
          </Tabs.Trigger>
        </Tabs.List>

        <Tabs.Content value="csv">
          <div
            className={`w-full p-8 border-2 border-dashed rounded-lg cursor-pointer transition-colors ${
              error ? 'border-red-500' : 'border-border hover:border-primary'
            }`}
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleDrop}
            onClick={() => document.getElementById('file-input')?.click()}
          >
            <div className="flex flex-col items-center space-y-4">
              <Upload className={`w-12 h-12 ${error ? 'text-red-500' : 'text-neon-purple'}`} />
              <h3 className="text-xl font-semibold">Upload do Arquivo CSV</h3>
              <p className="text-muted-foreground text-center">
                Arraste e solte seu arquivo CSV aqui, ou clique para selecionar
              </p>
              <div className="text-sm text-muted-foreground">
                <p>Campos necessários:</p>
                <ul className="list-disc list-inside mt-2">
                  {Object.keys(step === 'users' ? USER_CAMPOS : CAMPOS).map(campo => (
                    <li key={campo}>{campo}</li>
                  ))}
                </ul>
                <p className="mt-2 italic">
                  {step === 'users'
                    ? 'Os links devem ser separados por vírgula'
                    : 'Campos não encontrados serão ignorados no dashboard'}
                </p>
              </div>
              {error && (
                <div className="flex items-center space-x-2 text-red-500">
                  <AlertCircle className="w-4 h-4" />
                  <span className="text-sm">{error}</span>
                </div>
              )}
              <input
                id="file-input"
                type="file"
                accept=".csv"
                className="hidden"
                onChange={handleFileSelect}
              />
            </div>
          </div>
        </Tabs.Content>

        <Tabs.Content value="sheets">
          <div className="w-full p-8 border-2 border-dashed rounded-lg">
            <div className="flex flex-col items-center space-y-4">
              <FileSpreadsheet className={`w-12 h-12 ${error ? 'text-red-500' : 'text-neon-purple'}`} />
              <h3 className="text-xl font-semibold">Importar do Google Sheets</h3>
              <p className="text-muted-foreground text-center">
                Cole o link da sua planilha pública do Google Sheets
              </p>
              <div className="w-full max-w-md space-y-4">
                <input
                  type="text"
                  value={sheetUrl}
                  onChange={(e) => setSheetUrl(e.target.value)}
                  placeholder="https://docs.google.com/spreadsheets/d/..."
                  className="w-full px-4 py-2 bg-secondary rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                />
                <button
                  onClick={() => fetchSheetData()}
                  disabled={isLoading}
                  className="w-full px-4 py-2 bg-neon-blue text-background rounded-md hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoading ? 'Carregando...' : 'Carregar Planilha'}
                </button>
              </div>
              <div className="text-sm text-muted-foreground">
                <p>Campos necessários:</p>
                <ul className="list-disc list-inside mt-2">
                  {Object.keys(step === 'users' ? USER_CAMPOS : CAMPOS).map(campo => (
                    <li key={campo}>{campo}</li>
                  ))}
                </ul>
                <p className="mt-2 italic">
                  {step === 'users'
                    ? 'Os links devem ser separados por vírgula'
                    : 'Campos não encontrados serão ignorados no dashboard'}
                </p>
              </div>
              {error && (
                <div className="flex items-center space-x-2 text-red-500">
                  <AlertCircle className="w-4 h-4" />
                  <span className="text-sm">{error}</span>
                </div>
              )}
            </div>
          </div>
        </Tabs.Content>
      </Tabs.Root>

      <Dialog.Root open={isSheetModalOpen} onOpenChange={setIsSheetModalOpen}>
        <Dialog.Portal>
          <Dialog.Overlay className="fixed inset-0 bg-black/50 z-50" />
          <Dialog.Content className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-card p-6 rounded-lg shadow-xl w-full max-w-md z-50">
            <Dialog.Title className="text-lg font-semibold mb-4">
              Selecionar Página da Planilha
            </Dialog.Title>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-2">
                {sheets.map((sheet) => (
                  <button
                    key={sheet}
                    onClick={() => handleSheetSelect(sheet)}
                    className={`p-3 rounded-md transition-colors ${
                      selectedSheet === sheet
                        ? 'bg-neon-blue text-background'
                        : 'bg-secondary hover:bg-secondary/80'
                    }`}
                  >
                    {sheet}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex justify-end gap-2 mt-6">
              <Dialog.Close asChild>
                <button className="px-4 py-2 text-sm rounded-md bg-secondary hover:bg-secondary/80 transition-colors">
                  Cancelar
                </button>
              </Dialog.Close>
            </div>
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>
    </motion.div>
  );
}