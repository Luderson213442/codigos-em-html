import React, { useState, useEffect } from 'react';
import { format, subDays, startOfDay, endOfDay } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight } from 'lucide-react';
import { DateRange } from 'react-day-picker';
import * as Popover from '@radix-ui/react-popover';
import { DayPicker } from 'react-day-picker';

interface DatePreset {
  label: string;
  value: 'today' | '7days' | '30days' | 'all';
}

interface DateRangeFilterProps {
  dateRange: DateRange | undefined;
  onDateRangeChange: (range: DateRange | undefined) => void;
  placeholder?: string;
  title?: string;
  presets?: DatePreset[];
}

export function DateRangeFilter({ 
  dateRange, 
  onDateRangeChange, 
  placeholder = 'Filtrar por Data',
  title,
  presets = []
}: DateRangeFilterProps) {
  const [tempDate, setTempDate] = useState<Date | undefined>();
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    if (!isOpen) {
      setTempDate(undefined);
    }
  }, [isOpen]);

  const handleSelect = (date: Date | undefined) => {
    if (!date) {
      setTempDate(undefined);
      onDateRangeChange(undefined);
      return;
    }

    if (!tempDate) {
      setTempDate(date);
      onDateRangeChange({ from: date, to: date });
    } else {
      if (date > tempDate) {
        onDateRangeChange({ from: tempDate, to: date });
      } else if (date < tempDate) {
        onDateRangeChange({ from: date, to: tempDate });
      } else {
        onDateRangeChange({ from: date, to: date });
      }
      setTempDate(undefined);
      setIsOpen(false);
    }
  };

  const handlePresetSelect = (preset: 'today' | '7days' | '30days' | 'all') => {
    const today = endOfDay(new Date());
    switch (preset) {
      case 'today':
        onDateRangeChange({ 
          from: startOfDay(today), 
          to: endOfDay(today) 
        });
        break;
      case '7days':
        onDateRangeChange({ 
          from: startOfDay(subDays(today, 6)), // 6 days ago + today = 7 days
          to: endOfDay(today)
        });
        break;
      case '30days':
        onDateRangeChange({ 
          from: startOfDay(subDays(today, 29)), // 29 days ago + today = 30 days
          to: endOfDay(today)
        });
        break;
      case 'all':
        onDateRangeChange(undefined);
        break;
    }
    setIsOpen(false);
  };

  const formatDateRange = () => {
    if (!dateRange?.from) {
      return placeholder;
    }
    
    if (!dateRange.to || dateRange.from.getTime() === dateRange.to.getTime()) {
      return format(dateRange.from, 'dd/MM/yyyy');
    }
    
    return `${format(dateRange.from, 'dd/MM/yyyy')} - ${format(dateRange.to, 'dd/MM/yyyy')}`;
  };

  return (
    <div className="relative inline-block">
      {title && (
        <h3 className="text-lg font-semibold mb-2">{title}</h3>
      )}
      <Popover.Root open={isOpen} onOpenChange={setIsOpen}>
        <Popover.Trigger asChild>
          <button
            className={`
              inline-flex items-center justify-between gap-2 px-4 py-2 text-sm font-medium
              bg-secondary rounded-md hover:bg-secondary/80 transition-colors w-full
              ${dateRange?.from ? 'text-foreground' : 'text-muted-foreground'}
            `}
            type="button"
          >
            <div className="flex items-center gap-2">
              <CalendarIcon className="w-4 h-4" />
              <span>{formatDateRange()}</span>
            </div>
          </button>
        </Popover.Trigger>

        <Popover.Portal>
          <Popover.Content
            className="z-50 w-auto p-4 bg-popover text-popover-foreground rounded-md shadow-md"
            align="start"
            sideOffset={4}
          >
            <div className="flex flex-col space-y-4">
              {presets.length > 0 && (
                <div className="flex gap-2">
                  {presets.map(preset => (
                    <button
                      key={preset.value}
                      onClick={() => handlePresetSelect(preset.value)}
                      className={`
                        flex-1 px-3 py-1 text-sm rounded transition-colors
                        ${!dateRange && preset.value === 'all'
                          ? 'bg-neon-blue/20 text-neon-blue'
                          : dateRange?.from && preset.value === 'today' && format(dateRange.from, 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd')
                          ? 'bg-neon-blue/20 text-neon-blue'
                          : dateRange?.from && preset.value === '7days' && format(dateRange.from, 'yyyy-MM-dd') === format(subDays(new Date(), 6), 'yyyy-MM-dd')
                          ? 'bg-neon-blue/20 text-neon-blue'
                          : dateRange?.from && preset.value === '30days' && format(dateRange.from, 'yyyy-MM-dd') === format(subDays(new Date(), 29), 'yyyy-MM-dd')
                          ? 'bg-neon-blue/20 text-neon-blue'
                          : 'bg-secondary hover:bg-secondary/80'
                        }
                      `}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              )}

              <DayPicker
                locale={ptBR}
                mode="range"
                selected={tempDate ? { from: tempDate, to: tempDate } : dateRange}
                onSelect={(range) => {
                  if (!range?.from) {
                    onDateRangeChange(undefined);
                    setTempDate(undefined);
                  } else if (!range.to) {
                    setTempDate(range.from);
                    onDateRangeChange({ from: range.from, to: range.from });
                  } else {
                    setTempDate(undefined);
                    onDateRangeChange({
                      from: startOfDay(range.from),
                      to: endOfDay(range.to)
                    });
                    setIsOpen(false);
                  }
                }}
                defaultMonth={dateRange?.from || new Date()}
                numberOfMonths={2}
                classNames={{
                  months: 'flex flex-col sm:flex-row space-y-4 sm:space-x-4 sm:space-y-0',
                  month: 'space-y-4',
                  caption: 'flex justify-center pt-1 relative items-center',
                  caption_label: 'text-sm font-medium',
                  nav: 'space-x-1 flex items-center',
                  nav_button: 'h-7 w-7 bg-transparent p-0 opacity-50 hover:opacity-100',
                  nav_button_previous: 'absolute left-1',
                  nav_button_next: 'absolute right-1',
                  table: 'w-full border-collapse space-y-1',
                  head_row: 'flex',
                  head_cell: 'text-muted-foreground rounded-md w-9 font-normal text-[0.8rem]',
                  row: 'flex w-full mt-2',
                  cell: 'text-center text-sm p-0 relative [&:has([aria-selected])]:bg-accent first:[&:has([aria-selected])]:rounded-l-md last:[&:has([aria-selected])]:rounded-r-md focus-within:relative focus-within:z-20',
                  day: 'h-9 w-9 p-0 font-normal aria-selected:opacity-100',
                  day_selected: 'bg-neon-blue text-background hover:bg-neon-blue hover:text-background focus:bg-neon-blue focus:text-background',
                  day_today: 'bg-accent text-accent-foreground',
                  day_outside: 'text-muted-foreground opacity-50',
                  day_disabled: 'text-muted-foreground opacity-50',
                  day_range_start: 'bg-neon-blue text-background rounded-l-md',
                  day_range_end: 'bg-neon-blue text-background rounded-r-md',
                  day_range_middle: 'bg-neon-blue/20 text-foreground hover:bg-neon-blue/30',
                  day_hidden: 'invisible',
                }}
                components={{
                  IconLeft: () => <ChevronLeft className="h-4 w-4" />,
                  IconRight: () => <ChevronRight className="h-4 w-4" />,
                }}
                footer={
                  <div className="pt-4 text-xs text-muted-foreground">
                    {tempDate ? (
                      <p>Selecione uma data para definir o intervalo</p>
                    ) : (
                      <p>Clique em uma data para filtrar por dia</p>
                    )}
                  </div>
                }
              />
            </div>
          </Popover.Content>
        </Popover.Portal>
      </Popover.Root>
    </div>
  );
}