import React from 'react';
import { motion } from 'framer-motion';
import { Plus, X, Tag } from 'lucide-react';

interface TagFilterCondition {
  tag: string;
  type: 'is' | 'isNot';
}

interface TagFilterGroup {
  conditions: TagFilterCondition[];
  operator: 'AND' | 'OR';
}

interface TagFilterProps {
  allTags: string[];
  filterGroups: TagFilterGroup[];
  onUpdateFilters: (groups: TagFilterGroup[]) => void;
  isOpen: boolean;
  onClose: () => void;
}

export function TagFilter({ allTags, filterGroups, onUpdateFilters, isOpen, onClose }: TagFilterProps) {
  if (!isOpen) return null;

  const addNewGroup = () => {
    onUpdateFilters([...filterGroups, { conditions: [], operator: 'AND' }]);
  };

  const addConditionToGroup = (groupIndex: number) => {
    const newGroups = [...filterGroups];
    newGroups[groupIndex].conditions.push({ tag: allTags[0], type: 'is' });
    onUpdateFilters(newGroups);
  };

  const removeCondition = (groupIndex: number, conditionIndex: number) => {
    const newGroups = [...filterGroups];
    newGroups[groupIndex].conditions.splice(conditionIndex, 1);
    if (newGroups[groupIndex].conditions.length === 0) {
      newGroups.splice(groupIndex, 1);
    }
    onUpdateFilters(newGroups);
  };

  const updateCondition = (
    groupIndex: number,
    conditionIndex: number,
    updates: Partial<TagFilterCondition>
  ) => {
    const newGroups = [...filterGroups];
    newGroups[groupIndex].conditions[conditionIndex] = {
      ...newGroups[groupIndex].conditions[conditionIndex],
      ...updates,
    };
    onUpdateFilters(newGroups);
  };

  const toggleGroupOperator = (groupIndex: number) => {
    const newGroups = [...filterGroups];
    newGroups[groupIndex].operator = newGroups[groupIndex].operator === 'AND' ? 'OR' : 'AND';
    onUpdateFilters(newGroups);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-card p-6 rounded-lg shadow-xl w-full max-w-2xl"
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Tag className="w-5 h-5 text-neon-blue" />
            Filtro Avançado de Tags
          </h3>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground"
          >
            ✕
          </button>
        </div>

        <div className="space-y-4">
          {filterGroups.map((group, groupIndex) => (
            <div
              key={groupIndex}
              className="bg-secondary/30 p-4 rounded-lg space-y-3"
            >
              <div className="flex items-center justify-between mb-2">
                <button
                  onClick={() => toggleGroupOperator(groupIndex)}
                  className="text-sm font-medium text-neon-blue hover:text-neon-blue/80"
                >
                  {group.operator === 'AND' ? 'Todas as condições' : 'Qualquer condição'}
                </button>
                <button
                  onClick={() => addConditionToGroup(groupIndex)}
                  className="flex items-center gap-1 text-sm text-neon-green hover:text-neon-green/80"
                >
                  <Plus className="w-4 h-4" />
                  Adicionar Condição
                </button>
              </div>

              {group.conditions.map((condition, conditionIndex) => (
                <div
                  key={conditionIndex}
                  className="flex items-center gap-3 bg-secondary/50 p-3 rounded-md"
                >
                  <select
                    value={condition.type}
                    onChange={(e) =>
                      updateCondition(groupIndex, conditionIndex, {
                        type: e.target.value as 'is' | 'isNot',
                      })
                    }
                    className="bg-secondary text-sm rounded-md border-0 focus:ring-2 focus:ring-neon-blue"
                  >
                    <option value="is">É</option>
                    <option value="isNot">Não Está</option>
                  </select>

                  <select
                    value={condition.tag}
                    onChange={(e) =>
                      updateCondition(groupIndex, conditionIndex, {
                        tag: e.target.value,
                      })
                    }
                    className="flex-1 bg-secondary text-sm rounded-md border-0 focus:ring-2 focus:ring-neon-blue"
                  >
                    {allTags.map((tag) => (
                      <option key={tag} value={tag}>
                        {tag}
                      </option>
                    ))}
                  </select>

                  <button
                    onClick={() => removeCondition(groupIndex, conditionIndex)}
                    className="text-muted-foreground hover:text-destructive"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          ))}

          <button
            onClick={addNewGroup}
            className="w-full py-2 mt-4 flex items-center justify-center gap-2 bg-secondary/50 rounded-md hover:bg-secondary/70 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Novo Grupo de Filtros
          </button>
        </div>
      </motion.div>
    </div>
  );
}

export type { TagFilterGroup, TagFilterCondition };