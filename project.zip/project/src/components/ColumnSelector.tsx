import React from 'react';
import { Settings } from 'lucide-react';

export interface ColumnConfig {
  field: keyof LeadData;
  label: string;
  visible: boolean;
}

interface ColumnSelectorProps {
  columns: ColumnConfig[];
  onColumnToggle: (field: keyof LeadData) => void;
  isOpen: boolean;
  onClose: () => void;
}

export function ColumnSelector({ columns, onColumnToggle, isOpen, onClose }: ColumnSelectorProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-card p-6 rounded-lg shadow-xl w-full max-w-md">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Settings className="w-5 h-5 text-neon-blue" />
            Escolher Campos
          </h3>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground"
          >
            ✕
          </button>
        </div>
        <div className="space-y-3">
          {columns.map((column) => (
            <label
              key={column.field}
              className="flex items-center justify-between p-2 hover:bg-muted/50 rounded-md cursor-pointer"
            >
              <span className="text-sm">{column.label}</span>
              <div
                className={`w-10 h-6 rounded-full p-1 transition-colors duration-200 ease-in-out ${
                  column.visible ? 'bg-neon-blue' : 'bg-secondary'
                }`}
                onClick={() => onColumnToggle(column.field)}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-white transform transition-transform duration-200 ease-in-out ${
                    column.visible ? 'translate-x-4' : 'translate-x-0'
                  }`}
                />
              </div>
            </label>
          ))}
        </div>
      </div>
    </div>
  );
}