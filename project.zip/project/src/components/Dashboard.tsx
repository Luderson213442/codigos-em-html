import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  ResponsiveContainer,
} from 'recharts';
import { LeadData, ChartData } from '../types';
import { Tag, Settings, ChevronDown, Filter, ChevronLeft, ChevronRight } from 'lucide-react';
import { ColumnSelector, type ColumnConfig } from './ColumnSelector';
import { TagFilter, type TagFilterGroup } from './TagFilter';
import { DateRangeFilter } from './DateRangeFilter';
import { DateRange } from 'react-day-picker';
import { isWithinInterval, parseISO, startOfDay, endOfDay, format, eachDayOfInterval, subDays, isSameDay } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface DashboardProps {
  leads: LeadData[];
}

const COLORS = ['#00f2fe', '#8000ff', '#00ff9d'];

const INITIAL_COLUMNS: ColumnConfig[] = [
  { field: 'nome', label: 'Nome', visible: true },
  { field: 'empresa', label: 'Empresa', visible: true },
  { field: 'qualidade', label: 'Qualidade', visible: true },
  { field: 'whatsapp', label: 'WhatsApp', visible: false },
  { field: 'email', label: 'E-mail', visible: false },
  { field: 'faturamento', label: 'Faturamento', visible: false },
  { field: 'cargo', label: 'Cargo', visible: false },
  { field: 'motivo', label: 'Motivo', visible: false },
  { field: 'dataHora', label: 'Data e Hora', visible: false },
  { field: 'origem', label: 'Origem', visible: false },
  { field: 'tags', label: 'Tags', visible: true },
];

const isValidDate = (dateStr: string): boolean => {
  try {
    const date = parseISO(dateStr);
    return !isNaN(date.getTime());
  } catch {
    return false;
  }
};

export function Dashboard({ leads }: DashboardProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [columns, setColumns] = useState<ColumnConfig[]>(INITIAL_COLUMNS);
  const [isColumnSelectorOpen, setIsColumnSelectorOpen] = useState(false);
  const [isTagFilterOpen, setIsTagFilterOpen] = useState(false);
  const [tagFilterGroups, setTagFilterGroups] = useState<TagFilterGroup[]>([]);
  const [dateRange, setDateRange] = useState<DateRange | undefined>();
  const [graphDateRange, setGraphDateRange] = useState<DateRange | undefined>();

  const qualidadeData: ChartData[] = [
    { name: 'Alta', value: leads.filter((lead) => lead.qualidade === 'Alta').length },
    { name: 'Média', value: leads.filter((lead) => lead.qualidade === 'Média').length },
    { name: 'Baixa', value: leads.filter((lead) => lead.qualidade === 'Baixa').length },
  ];

  const allTags = Array.from(
    new Set(
      leads.flatMap(lead => 
        lead.tags.flatMap(tag => tag.split(',').map(t => t.trim()))
      )
    )
  ).filter(Boolean).sort();

  const getLeadTags = (lead: LeadData): string[] => {
    return lead.tags.flatMap(tag => tag.split(',').map(t => t.trim())).filter(Boolean);
  };

  const filteredLeads = leads.filter((lead) => {
    const matchesSearch = !searchTerm || 
      lead.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.empresa.toLowerCase().includes(searchTerm.toLowerCase());
    
    const leadTags = getLeadTags(lead);
    
    const matchesTags = tagFilterGroups.length === 0 || tagFilterGroups.some(group => {
      const groupMatches = group.conditions.every(condition => {
        const hasTag = leadTags.includes(condition.tag);
        return condition.type === 'is' ? hasTag : !hasTag;
      });
      
      if (group.operator === 'OR') {
        return group.conditions.some(condition => {
          const hasTag = leadTags.includes(condition.tag);
          return condition.type === 'is' ? hasTag : !hasTag;
        });
      }
      
      return groupMatches;
    });

    const matchesDateRange = !dateRange?.from || !dateRange?.to || (
      lead.dataHora && 
      isValidDate(lead.dataHora) && 
      isWithinInterval(
        parseISO(lead.dataHora),
        { start: startOfDay(dateRange.from), end: endOfDay(dateRange.to) }
      )
    );
    
    return matchesSearch && matchesTags && matchesDateRange;
  });

  const timeSeriesData = useMemo(() => {
    // Get the date range for the graph
    let startDate = graphDateRange?.from;
    let endDate = graphDateRange?.to;

    if (!startDate || !endDate) {
      // If no date range is selected, find the min and max dates from leads
      const validDates = leads
        .map(lead => lead.dataHora)
        .filter(isValidDate)
        .map(dateStr => parseISO(dateStr));

      if (validDates.length > 0) {
        startDate = new Date(Math.min(...validDates.map(d => d.getTime())));
        endDate = new Date(Math.max(...validDates.map(d => d.getTime())));
      } else {
        // If no valid dates, use last 30 days
        endDate = new Date();
        startDate = subDays(endDate, 30);
      }
    }

    // If we're looking at a single day, adjust the range to show hourly data
    const isSingleDay = startDate && endDate && isSameDay(startDate, endDate);
    
    const dateCountMap = new Map<string, number>();
    const totalCountMap = new Map<string, number>();
    
    if (isSingleDay) {
      // Initialize maps with all hours in the day
      for (let hour = 0; hour < 24; hour++) {
        const hourStr = hour.toString().padStart(2, '0');
        dateCountMap.set(hourStr, 0);
        totalCountMap.set(hourStr, 0);
      }

      // Count leads for each hour
      leads.forEach(lead => {
        if (lead.dataHora && isValidDate(lead.dataHora)) {
          try {
            const leadDate = parseISO(lead.dataHora);
            if (isSameDay(leadDate, startDate)) {
              const hour = leadDate.getHours().toString().padStart(2, '0');
              
              // Update total count
              totalCountMap.set(hour, (totalCountMap.get(hour) || 0) + 1);

              // Update filtered count based on search and tags
              const leadTags = getLeadTags(lead);
              const matchesSearch = !searchTerm || 
                lead.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
                lead.empresa.toLowerCase().includes(searchTerm.toLowerCase());
              
              const matchesTags = tagFilterGroups.length === 0 || tagFilterGroups.some(group => {
                const groupMatches = group.conditions.every(condition => {
                  const hasTag = leadTags.includes(condition.tag);
                  return condition.type === 'is' ? hasTag : !hasTag;
                });
                
                if (group.operator === 'OR') {
                  return group.conditions.some(condition => {
                    const hasTag = leadTags.includes(condition.tag);
                    return condition.type === 'is' ? hasTag : !hasTag;
                  });
                }
                
                return groupMatches;
              });

              if (matchesSearch && matchesTags) {
                dateCountMap.set(hour, (dateCountMap.get(hour) || 0) + 1);
              }
            }
          } catch (error) {
            console.warn('Invalid date format:', lead.dataHora);
          }
        }
      });

      // Convert maps to array and sort by hour
      return Array.from(dateCountMap.entries())
        .map(([hour, filteredCount]) => ({
          date: `${hour}:00`,
          fullDate: hour,
          'Leads Filtrados': filteredCount,
          'Total de Leads': totalCountMap.get(hour) || 0
        }))
        .sort((a, b) => a.fullDate.localeCompare(b.fullDate));
    } else {
      // Initialize maps with all dates in the range
      eachDayOfInterval({
        start: startOfDay(startDate),
        end: endOfDay(endDate)
      }).forEach(date => {
        const dateStr = format(date, 'yyyy-MM-dd');
        dateCountMap.set(dateStr, 0);
        totalCountMap.set(dateStr, 0);
      });

      // Count leads for each date
      leads.forEach(lead => {
        if (lead.dataHora && isValidDate(lead.dataHora)) {
          try {
            const leadDate = parseISO(lead.dataHora);
            if (isWithinInterval(leadDate, { start: startOfDay(startDate), end: endOfDay(endDate) })) {
              const dateStr = format(leadDate, 'yyyy-MM-dd');
              
              // Update total count
              totalCountMap.set(dateStr, (totalCountMap.get(dateStr) || 0) + 1);

              // Update filtered count based on search and tags
              const leadTags = getLeadTags(lead);
              const matchesSearch = !searchTerm || 
                lead.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
                lead.empresa.toLowerCase().includes(searchTerm.toLowerCase());
              
              const matchesTags = tagFilterGroups.length === 0 || tagFilterGroups.some(group => {
                const groupMatches = group.conditions.every(condition => {
                  const hasTag = leadTags.includes(condition.tag);
                  return condition.type === 'is' ? hasTag : !hasTag;
                });
                
                if (group.operator === 'OR') {
                  return group.conditions.some(condition => {
                    const hasTag = leadTags.includes(condition.tag);
                    return condition.type === 'is' ? hasTag : !hasTag;
                  });
                }
                
                return groupMatches;
              });

              if (matchesSearch && matchesTags) {
                dateCountMap.set(dateStr, (dateCountMap.get(dateStr) || 0) + 1);
              }
            }
          } catch (error) {
            console.warn('Invalid date format:', lead.dataHora);
          }
        }
      });

      // Convert maps to array and sort by date
      return Array.from(dateCountMap.entries())
        .map(([date, filteredCount]) => ({
          date: format(parseISO(date), 'dd/MM', { locale: ptBR }),
          fullDate: date,
          'Leads Filtrados': filteredCount,
          'Total de Leads': totalCountMap.get(date) || 0
        }))
        .sort((a, b) => a.fullDate.localeCompare(b.fullDate));
    }
  }, [leads, graphDateRange, searchTerm, tagFilterGroups]);

  const handleGraphDatePreset = (preset: 'today' | '7days' | '30days' | 'all') => {
    const today = new Date();
    switch (preset) {
      case 'today':
        setGraphDateRange({ from: today, to: today });
        break;
      case '7days':
        setGraphDateRange({ from: subDays(today, 7), to: today });
        break;
      case '30days':
        setGraphDateRange({ from: subDays(today, 30), to: today });
        break;
      case 'all':
        setGraphDateRange(undefined);
        break;
    }
  };

  const handleColumnToggle = (field: keyof LeadData) => {
    setColumns(prev =>
      prev.map(col =>
        col.field === field ? { ...col, visible: !col.visible } : col
      )
    );
  };

  const visibleColumns = columns.filter(col => col.visible);

  const renderCellContent = (lead: LeadData, column: ColumnConfig) => {
    if (column.field === 'qualidade') {
      return (
        <span
          className={`px-2 py-1 rounded-full text-xs ${
            lead.qualidade === 'Alta'
              ? 'bg-neon-green/20 text-neon-green'
              : lead.qualidade === 'Média'
              ? 'bg-neon-blue/20 text-neon-blue'
              : 'bg-neon-purple/20 text-neon-purple'
          }`}
        >
          {lead.qualidade}
        </span>
      );
    }
    
    if (column.field === 'tags') {
      const tags = getLeadTags(lead);
      if (tags.length === 0) return null;
      
      return (
        <div className="flex flex-wrap gap-1">
          {tags.map((tag, index) => (
            <span
              key={`${lead.id}-${tag}-${index}`}
              className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs ${
                tagFilterGroups.some(group =>
                  group.conditions.some(condition =>
                    condition.tag === tag &&
                    ((condition.type === 'is' && tags.includes(tag)) ||
                     (condition.type === 'isNot' && !tags.includes(tag)))
                  )
                )
                  ? 'bg-neon-green/20 text-neon-green'
                  : 'bg-gray-600/20 text-gray-400'
              }`}
            >
              {tag}
            </span>
          ))}
        </div>
      );
    }

    if (column.field === 'dataHora' && lead.dataHora) {
      try {
        return format(parseISO(lead.dataHora), 'dd/MM/yyyy HH:mm', { locale: ptBR });
      } catch {
        return lead.dataHora;
      }
    }
    
    return lead[column.field];
  };

  return (
    <div className="space-y-8">
      <motion.div
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="bg-card p-6 rounded-lg shadow-lg">
          <h3 className="text-lg font-semibold mb-4">Distribuição por Qualidade</h3>
          <PieChart width={300} height={200}>
            <Pie
              data={qualidadeData}
              cx={150}
              cy={100}
              innerRadius={60}
              outerRadius={80}
              paddingAngle={5}
              dataKey="value"
            >
              {qualidadeData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
          </PieChart>
        </div>

        <div className="bg-card p-6 rounded-lg shadow-lg">
          <h3 className="text-lg font-semibold mb-4">Estatísticas Rápidas</h3>
          <div className="space-y-4">
            <div>
              <p className="text-sm text-muted-foreground">Total de Leads</p>
              <p className="text-2xl font-bold text-neon-purple">{leads.length}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Leads de Alta Qualidade</p>
              <p className="text-2xl font-bold text-neon-blue">
                {leads.filter((lead) => lead.qualidade === 'Alta').length}
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Leads de Média Qualidade</p>
              <p className="text-2xl font-bold text-neon-green">
                {leads.filter((lead) => lead.qualidade === 'Média').length}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-card p-6 rounded-lg shadow-lg">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold">Distribuição por Data</h3>
            <div className="flex gap-2 text-xs">
              <button
                onClick={() => handleGraphDatePreset('today')}
                className={`px-2 py-1 rounded ${
                  graphDateRange?.from && format(graphDateRange.from, 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd')
                    ? 'bg-neon-blue/20 text-neon-blue'
                    : 'bg-secondary hover:bg-secondary/80'
                }`}
              >
                Hoje
              </button>
              <button
                onClick={() => handleGraphDatePreset('7days')}
                className={`px-2 py-1 rounded ${
                  graphDateRange?.from && format(graphDateRange.from, 'yyyy-MM-dd') === format(subDays(new Date(), 7), 'yyyy-MM-dd')
                    ? 'bg-neon-blue/20 text-neon-blue'
                    : 'bg-secondary hover:bg-secondary/80'
                }`}
              >
                Últimos 7 dias
              </button>
              <button
                onClick={() => handleGraphDatePreset('30days')}
                className={`px-2 py-1 rounded ${
                  graphDateRange?.from && format(graphDateRange.from, 'yyyy-MM-dd') === format(subDays(new Date(), 30), 'yyyy-MM-dd')
                    ? 'bg-neon-blue/20 text-neon-blue'
                    : 'bg-secondary hover:bg-secondary/80'
                }`}
              >
                Últimos 30 dias
              </button>
              <button
                onClick={() => handleGraphDatePreset('all')}
                className={`px-2 py-1 rounded ${
                  !graphDateRange
                    ? 'bg-neon-blue/20 text-neon-blue'
                    : 'bg-secondary hover:bg-secondary/80'
                }`}
              >
                Tempo todo
              </button>
            </div>
          </div>
          <div className="mb-4">
            <DateRangeFilter
              dateRange={graphDateRange}
              onDateRangeChange={setGraphDateRange}
              placeholder="Selecionar período personalizado"
            />
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={timeSeriesData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis
                dataKey="date"
                stroke="#6B7280"
                fontSize={12}
                tickLine={false}
              />
              <YAxis
                stroke="#6B7280"
                fontSize={12}
                tickLine={false}
                allowDecimals={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(17, 24, 39, 0.8)',
                  border: 'none',
                  borderRadius: '4px',
                  fontSize: '12px',
                }}
              />
              <Line
                type="monotone"
                dataKey="Total de Leads"
                stroke="#8000ff"
                strokeWidth={2}
                dot={false}
              />
              <Line
                type="monotone"
                dataKey="Leads Filtrados"
                stroke="#00f2fe"
                strokeWidth={2}
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      <div className="space-y-4">
        <div className="flex flex-wrap gap-4">
          <input
            type="text"
            placeholder="Pesquisar leads..."
            className="px-4 py-2 bg-secondary rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <button
            onClick={() => setIsColumnSelectorOpen(true)}
            style={{ backgroundColor: '#0d6fe8', color: '#09090b' }}
            className="px-4 py-2 rounded-md hover:opacity-90 transition-opacity flex items-center gap-2"
          >
            <Settings className="w-4 h-4" />
            Escolher Campos
          </button>
          <button
            onClick={() => setIsTagFilterOpen(true)}
            className="px-4 py-2 bg-secondary rounded-md hover:bg-secondary/80 transition-colors flex items-center gap-2"
          >
            <Filter className="w-4 h-4" />
            Filtro Avançado de Tags
            {tagFilterGroups.length > 0 && (
              <span className="px-2 py-0.5 text-xs bg-neon-blue/20 text-neon-blue rounded-full">
                {tagFilterGroups.reduce((acc, group) => acc + group.conditions.length, 0)}
              </span>
            )}
          </button>
          <DateRangeFilter
            dateRange={dateRange}
            onDateRangeChange={setDateRange}
            placeholder="Filtrar tabela por data"
          />
          {(tagFilterGroups.length > 0 || dateRange) && (
            <button
              onClick={() => {
                setTagFilterGroups([]);
                setDateRange(undefined);
              }}
              className="px-3 py-1 text-sm text-destructive hover:text-destructive/80 transition-colors"
            >
              Limpar Filtros
            </button>
          )}
        </div>

        <div className="bg-card rounded-lg shadow-lg overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border/50">
                {visibleColumns.map(column => (
                  <th key={column.field} className="p-4 text-left">
                    {column.label}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filteredLeads.map((lead) => (
                <motion.tr
                  key={lead.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.3 }}
                  className="border-b border-border/50 hover:bg-muted/50"
                >
                  {visibleColumns.map(column => (
                    <td key={column.field} className="p-4">
                      {renderCellContent(lead, column)}
                    </td>
                  ))}
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <ColumnSelector
        columns={columns}
        onColumnToggle={handleColumnToggle}
        isOpen={isColumnSelectorOpen}
        onClose={() => setIsColumnSelectorOpen(false)}
      />

      <TagFilter
        allTags={allTags}
        filterGroups={tagFilterGroups}
        onUpdateFilters={setTagFilterGroups}
        isOpen={isTagFilterOpen}
        onClose={() => setIsTagFilterOpen(false)}
      />
    </div>
  );
}