import React, { useState } from 'react';
import { Pencil, X } from 'lucide-react';
import * as Dialog from '@radix-ui/react-dialog';
import { LeadData } from '../types';
import { AnimatedCounter } from './AnimatedCounter';

interface EditableMetricCardProps {
  title: string;
  icon: React.ReactNode;
  iconColor: string;
  tag: string;
  leads: LeadData[];
  onUpdate: (newTitle: string, newTag: string) => void;
  isEditable?: boolean;
  bgColor?: string;
  textColor?: string;
  allTags: string[];
}

export function EditableMetricCard({
  title,
  icon,
  iconColor,
  tag,
  leads,
  onUpdate,
  isEditable = true,
  bgColor = 'bg-card',
  textColor = 'text-foreground',
  allTags
}: EditableMetricCardProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [newTitle, setNewTitle] = useState(title);
  const [newTag, setNewTag] = useState(tag);
  const [showEditButton, setShowEditButton] = useState(false);

  const count = tag ? leads.filter(lead => 
    lead.tags.some(t => t.includes(tag))
  ).length : leads.length;

  const handleSave = () => {
    onUpdate(newTitle, newTag);
    setIsOpen(false);
  };

  return (
    <div
      className={`${bgColor} p-4 rounded-lg flex justify-between items-center border border-border/50 relative group cursor-default`}
      onMouseEnter={() => setShowEditButton(true)}
      onMouseLeave={() => setShowEditButton(false)}
    >
      <div>
        <p className={`text-sm ${textColor === 'text-foreground' ? 'text-muted-foreground' : textColor}`}>
          {title}
        </p>
        <AnimatedCounter value={count} className={`text-4xl font-bold ${textColor}`} />
      </div>
      <div className={iconColor}>{icon}</div>

      {isEditable && (
        <Dialog.Root open={isOpen} onOpenChange={setIsOpen}>
          <Dialog.Trigger asChild>
            <button
              className={`
                absolute top-2 right-2 p-1.5 rounded-full
                bg-white/10 hover:bg-white/20 backdrop-blur-sm
                transition-all duration-200 z-10
                ${showEditButton ? 'opacity-100 visible' : 'opacity-0 invisible'}
              `}
            >
              <Pencil className="w-4 h-4 text-white" />
            </button>
          </Dialog.Trigger>

          <Dialog.Portal>
            <Dialog.Overlay className="fixed inset-0 bg-black/50 z-50" />
            <Dialog.Content className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-card p-6 rounded-lg shadow-xl w-full max-w-md z-50">
              <div className="flex justify-between items-center mb-4">
                <Dialog.Title className="text-lg font-semibold">
                  Editar Métrica
                </Dialog.Title>
                <Dialog.Close asChild>
                  <button className="text-muted-foreground hover:text-foreground">
                    <X className="w-4 h-4" />
                  </button>
                </Dialog.Close>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">
                    Nome do Campo
                  </label>
                  <input
                    type="text"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    className="w-full px-3 py-2 bg-secondary rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">
                    Tag para Contagem
                  </label>
                  <select
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    className="w-full px-3 py-2 bg-secondary rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                  >
                    <option value="">Selecione uma tag</option>
                    {allTags.map((tag) => (
                      <option key={tag} value={tag}>
                        {tag}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex justify-end gap-2 mt-6">
                  <Dialog.Close asChild>
                    <button className="px-4 py-2 text-sm rounded-md bg-secondary hover:bg-secondary/80 transition-colors">
                      Cancelar
                    </button>
                  </Dialog.Close>
                  <button
                    onClick={handleSave}
                    className="px-4 py-2 text-sm rounded-md bg-neon-blue text-background hover:opacity-90 transition-opacity"
                  >
                    Alterar
                  </button>
                </div>
              </div>
            </Dialog.Content>
          </Dialog.Portal>
        </Dialog.Root>
      )}
    </div>
  );
}