import React from 'react';
import { motion } from 'framer-motion';
import { UserProfile } from '../types';
import { ChevronDown } from 'lucide-react';
import * as Popover from '@radix-ui/react-popover';

interface UserProfileSelectorProps {
  profiles: UserProfile[];
  selectedProfile: UserProfile | null;
  onSelectProfile: (profile: UserProfile) => void;
}

export function UserProfileSelector({
  profiles,
  selectedProfile,
  onSelectProfile
}: UserProfileSelectorProps) {
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <Popover.Root open={isOpen} onOpenChange={setIsOpen}>
      <Popover.Trigger asChild>
        <button
          className={`
            inline-flex items-center justify-between gap-2 px-4 py-2 text-sm font-medium
            bg-secondary rounded-md hover:bg-secondary/80 transition-colors w-[200px]
            ${selectedProfile ? 'text-foreground' : 'text-muted-foreground'}
          `}
        >
          <span className="truncate">
            {selectedProfile ? selectedProfile.user : 'Selecionar Perfil'}
          </span>
          <ChevronDown className="w-4 h-4" />
        </button>
      </Popover.Trigger>

      <Popover.Portal>
        <Popover.Content
          className="z-50 w-[200px] p-1 bg-popover text-popover-foreground rounded-md shadow-md"
          align="start"
          sideOffset={4}
        >
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-1"
          >
            {profiles.map((profile) => (
              <button
                key={profile.email}
                onClick={() => {
                  onSelectProfile(profile);
                  setIsOpen(false);
                }}
                className={`
                  w-full px-3 py-2 text-sm rounded-md text-left transition-colors
                  ${selectedProfile?.email === profile.email
                    ? 'bg-neon-blue/20 text-neon-blue'
                    : 'hover:bg-secondary/80'
                  }
                `}
              >
                <div className="flex flex-col">
                  <span className="font-medium">{profile.user}</span>
                  <span className="text-xs text-muted-foreground">{profile.email}</span>
                </div>
              </button>
            ))}
          </motion.div>
        </Popover.Content>
      </Popover.Portal>
    </Popover.Root>
  );
}