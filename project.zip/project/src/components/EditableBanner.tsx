import React, { useState, useCallback } from 'react';
import { Pencil, X, Upload } from 'lucide-react';
import * as Dialog from '@radix-ui/react-dialog';
import { useDropzone } from 'react-dropzone';

interface EditableBannerProps {
  title: string;
  description: string;
  imageUrl: string;
  onUpdate: (newTitle: string, newDescription: string, newImageUrl: string) => void;
}

export function EditableBanner({
  title,
  description,
  imageUrl,
  onUpdate
}: EditableBannerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [newTitle, setNewTitle] = useState(title);
  const [newDescription, setNewDescription] = useState(description);
  const [previewImage, setPreviewImage] = useState<string>(imageUrl);
  const [showEditButton, setShowEditButton] = useState(false);
  const [isDragging, setIsDragging] = useState(false);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setPreviewImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.png', '.jpg', '.jpeg', '.gif']
    },
    maxFiles: 1,
    multiple: false
  });

  const handleSave = () => {
    onUpdate(newTitle, newDescription, previewImage);
    setIsOpen(false);
  };

  return (
    <div
      className="relative h-48 rounded-lg overflow-hidden group cursor-default"
      onMouseEnter={() => setShowEditButton(true)}
      onMouseLeave={() => setShowEditButton(false)}
    >
      <img
        src={imageUrl}
        alt="Dashboard Banner"
        className="w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-transparent flex items-center p-8">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">
            {title}
          </h1>
          <p className="text-gray-200">
            {description}
          </p>
        </div>
      </div>

      <Dialog.Root open={isOpen} onOpenChange={setIsOpen}>
        <Dialog.Trigger asChild>
          <button
            className={`
              absolute top-3 right-3 p-2.5 rounded-lg
              bg-black/20 hover:bg-black/40
              backdrop-blur-sm border border-white/10
              transition-all duration-200 ease-in-out
              ${showEditButton ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-2'}
            `}
          >
            <Pencil className="w-5 h-5 text-white" />
          </button>
        </Dialog.Trigger>

        <Dialog.Portal>
          <Dialog.Overlay className="fixed inset-0 bg-black/50 z-50" />
          <Dialog.Content className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-card p-6 rounded-lg shadow-xl w-full max-w-md z-50">
            <div className="flex justify-between items-center mb-4">
              <Dialog.Title className="text-lg font-semibold">
                Editar Banner
              </Dialog.Title>
              <Dialog.Close asChild>
                <button className="text-muted-foreground hover:text-foreground">
                  <X className="w-4 h-4" />
                </button>
              </Dialog.Close>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">
                  Título
                </label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-3 py-2 bg-secondary rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">
                  Descrição
                </label>
                <input
                  type="text"
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  className="w-full px-3 py-2 bg-secondary rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">
                  Imagem do Banner
                </label>
                <div
                  {...getRootProps()}
                  className={`
                    mt-1 flex justify-center rounded-lg border border-dashed px-6 py-8
                    ${isDragActive 
                      ? 'border-neon-blue bg-neon-blue/5' 
                      : 'border-border hover:border-neon-blue/50'
                    }
                    transition-colors duration-200 cursor-pointer
                  `}
                >
                  <div className="text-center">
                    <Upload className={`mx-auto h-12 w-12 ${isDragActive ? 'text-neon-blue' : 'text-muted-foreground'}`} />
                    <div className="mt-4 flex text-sm leading-6">
                      <input {...getInputProps()} />
                      <span className="text-muted-foreground">
                        Arraste e solte uma imagem aqui, ou{' '}
                        <span className="text-neon-blue font-semibold">
                          clique para selecionar
                        </span>
                      </span>
                    </div>
                    <p className="text-xs leading-5 text-muted-foreground mt-1">
                      PNG, JPG ou GIF (max. 10MB)
                    </p>
                  </div>
                </div>
              </div>

              {previewImage && (
                <div className="relative mt-4 rounded-lg overflow-hidden">
                  <img
                    src={previewImage}
                    alt="Preview"
                    className="w-full h-32 object-cover rounded-lg"
                  />
                  <button
                    onClick={() => setPreviewImage(imageUrl)}
                    className="absolute top-2 right-2 p-1 rounded-full bg-black/50 hover:bg-black/70 transition-colors"
                  >
                    <X className="w-4 h-4 text-white" />
                  </button>
                </div>
              )}

              <div className="flex justify-end gap-2 mt-6">
                <Dialog.Close asChild>
                  <button className="px-4 py-2 text-sm rounded-md bg-secondary hover:bg-secondary/80 transition-colors">
                    Cancelar
                  </button>
                </Dialog.Close>
                <button
                  onClick={handleSave}
                  className="px-4 py-2 text-sm rounded-md bg-neon-blue text-background hover:opacity-90 transition-opacity"
                >
                  Salvar
                </button>
              </div>
            </div>
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>
    </div>
  );
}