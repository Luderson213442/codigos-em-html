import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { UserProfile } from '../types';
import { Link, ChevronDown, RefreshCw, AlertCircle } from 'lucide-react';
import * as Dialog from '@radix-ui/react-dialog';
import * as XLSX from 'xlsx';

interface UserDashboardProps {
  profile: UserProfile;
  onSelectLink: (link: string, sheetName: string) => void;
  selectedSheet?: { link: string; sheet: string } | null;
}

interface SheetInfo {
  title: string;
  sheets: string[];
  error?: string;
}

export function UserDashboard({ profile, onSelectLink, selectedSheet }: UserDashboardProps) {
  const [sheetInfo, setSheetInfo] = useState<{ [key: string]: SheetInfo }>({});
  const [selectedLink, setSelectedLink] = useState<string | null>(null);
  const [isSheetModalOpen, setIsSheetModalOpen] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState<{ [key: string]: boolean }>({});
  const [hoveredLink, setHoveredLink] = useState<string | null>(null);
  const [loadingStates, setLoadingStates] = useState<{ [key: string]: boolean }>({});

  const loadSheetInfo = async (link: string) => {
    if (!link.includes('/spreadsheets/d/')) {
      setSheetInfo(prev => ({
        ...prev,
        [link]: {
          title: 'URL Inválida',
          sheets: [],
          error: 'URL inválida. Use um link válido do Google Sheets.'
        }
      }));
      return;
    }

    setLoadingStates(prev => ({ ...prev, [link]: true }));
    
    try {
      const matches = link.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
      if (!matches) {
        throw new Error('URL inválida. Não foi possível encontrar o ID da planilha.');
      }

      const id = matches[1];
      const exportUrl = `https://docs.google.com/spreadsheets/d/${id}/export?format=xlsx`;
      
      const response = await fetch(exportUrl);
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error('Planilha não encontrada. Verifique se o link está correto.');
        } else if (response.status === 403) {
          throw new Error('Acesso negado. Verifique se a planilha está pública.');
        } else {
          throw new Error(`Erro ao acessar a planilha (${response.status})`);
        }
      }

      const arrayBuffer = await response.arrayBuffer();
      const workbook = XLSX.read(arrayBuffer, { type: 'array' });
      
      if (!workbook.SheetNames.length) {
        throw new Error('A planilha não contém páginas.');
      }

      setSheetInfo(prev => ({
        ...prev,
        [link]: {
          title: workbook.Props?.Title || workbook.SheetNames[0] || 'Planilha sem título',
          sheets: workbook.SheetNames
        }
      }));
    } catch (error) {
      console.error('Error loading sheet:', error);
      setSheetInfo(prev => ({
        ...prev,
        [link]: {
          title: 'Erro ao carregar',
          sheets: [],
          error: error instanceof Error ? error.message : 'Erro desconhecido ao carregar a planilha'
        }
      }));
    } finally {
      setLoadingStates(prev => ({ ...prev, [link]: false }));
    }
  };

  useEffect(() => {
    profile.links.forEach(link => {
      if (!sheetInfo[link]) {
        loadSheetInfo(link);
      }
    });
  }, [profile.links]);

  const handleLinkClick = (link: string) => {
    const info = sheetInfo[link];
    if (info?.error) {
      loadSheetInfo(link);
      return;
    }
    
    if (info && info.sheets.length > 1) {
      setSelectedLink(link);
      setIsSheetModalOpen(true);
    } else if (info && info.sheets.length === 1) {
      handleSelectSheet(link, info.sheets[0]);
    }
  };

  const handleSelectSheet = async (link: string, sheetName: string) => {
    setIsRefreshing(prev => ({ ...prev, [link]: true }));
    try {
      await onSelectLink(link, sheetName);
    } catch (error) {
      console.error('Error selecting sheet:', error);
      setSheetInfo(prev => ({
        ...prev,
        [link]: {
          ...prev[link],
          error: error instanceof Error ? error.message : 'Erro ao selecionar a página'
        }
      }));
    } finally {
      setIsRefreshing(prev => ({ ...prev, [link]: false }));
    }
    setIsSheetModalOpen(false);
  };

  const handleRetry = (link: string, e: React.MouseEvent) => {
    e.stopPropagation();
    loadSheetInfo(link);
  };

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="bg-card rounded-lg p-6 border border-border/50"
      >
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold">{profile.user}</h2>
            <p className="text-muted-foreground">{profile.email}</p>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Link className="w-5 h-5 text-neon-blue" />
            Base de dados
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {profile.links.map((link, index) => {
              const info = sheetInfo[link];
              const isLoading = loadingStates[link];
              const hasError = info?.error;
              const hasMultipleSheets = info?.sheets.length > 1;
              const isActive = selectedSheet?.link === link;
              const isCurrentlyRefreshing = isRefreshing[link];
              const isHovered = hoveredLink === link;
              
              return (
                <motion.div
                  key={index}
                  role="button"
                  tabIndex={0}
                  onClick={() => handleLinkClick(link)}
                  onMouseEnter={() => setHoveredLink(link)}
                  onMouseLeave={() => setHoveredLink(null)}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      handleLinkClick(link);
                    }
                  }}
                  className={`
                    relative p-4 rounded-lg text-left transition-all duration-200 cursor-pointer
                    ${hasError
                      ? 'bg-red-500/10 border-2 border-red-500/50'
                      : isActive 
                        ? 'bg-neon-blue/10 border-2 border-neon-blue shadow-[0_0_15px_rgba(0,242,254,0.3)]' 
                        : 'bg-secondary/50 hover:bg-secondary/70 border-2 border-transparent'
                    }
                  `}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <div className="flex items-center gap-3">
                    <Link 
                      className={`w-4 h-4 transition-colors ${
                        hasError
                          ? 'text-red-500'
                          : isActive 
                            ? 'text-neon-blue' 
                            : isHovered 
                              ? 'text-neon-green' 
                              : 'text-muted-foreground'
                      }`}
                    />
                    <span className={`text-sm font-medium truncate flex-1 transition-colors ${
                      hasError
                        ? 'text-red-500'
                        : isActive 
                          ? 'text-neon-blue' 
                          : 'text-foreground'
                    }`}>
                      {isLoading ? 'Carregando...' : info?.title || 'Carregando...'}
                    </span>
                    {!hasError && hasMultipleSheets && (
                      <ChevronDown className={`w-4 h-4 transition-colors ${
                        isActive 
                          ? 'text-neon-blue' 
                          : isHovered 
                            ? 'text-neon-green' 
                            : 'text-muted-foreground'
                      }`} />
                    )}
                    {isCurrentlyRefreshing && (
                      <RefreshCw className="w-4 h-4 text-neon-blue animate-spin" />
                    )}
                    {hasError && (
                      <AlertCircle className="w-4 h-4 text-red-500" />
                    )}
                  </div>

                  {hasError ? (
                    <div className="mt-2">
                      <p className="text-xs text-red-500">{info.error}</p>
                      <div 
                        role="button"
                        tabIndex={0}
                        onClick={(e) => handleRetry(link, e)}
                        onKeyPress={(e) => {
                          if (e.key === 'Enter' || e.key === ' ') {
                            handleRetry(link, e as any);
                          }
                        }}
                        className="mt-2 text-xs text-neon-blue hover:underline cursor-pointer"
                      >
                        Tentar novamente
                      </div>
                    </div>
                  ) : (
                    <>
                      {hasMultipleSheets && (
                        <div className="flex items-center justify-between mt-1">
                          <p className={`text-xs transition-colors ${
                            isActive ? 'text-neon-blue' : 'text-muted-foreground'
                          }`}>
                            {info?.sheets.length} páginas disponíveis
                          </p>
                          {isActive && selectedSheet?.sheet && (
                            <p className="text-xs text-neon-green">
                              Página atual: {selectedSheet.sheet}
                            </p>
                          )}
                        </div>
                      )}

                      <p className={`mt-2 text-xs truncate transition-colors ${
                        isActive 
                          ? 'text-neon-blue/70' 
                          : isHovered 
                            ? 'text-foreground' 
                            : 'text-muted-foreground'
                      }`}>
                        {link}
                      </p>

                      {isActive && (
                        <>
                          <div className="absolute -top-2 -right-2 w-4 h-4 bg-neon-blue rounded-full animate-pulse" />
                          <div className="absolute -top-2 -right-2 w-4 h-4 bg-neon-blue rounded-full animate-ping opacity-75" />
                        </>
                      )}

                      {isHovered && !isActive && (
                        <div className="absolute -top-2 -right-2 w-4 h-4 bg-neon-green rounded-full transition-transform scale-75" />
                      )}
                    </>
                  )}
                </motion.div>
              );
            })}
          </div>
        </div>
      </motion.div>

      <Dialog.Root open={isSheetModalOpen} onOpenChange={setIsSheetModalOpen}>
        <Dialog.Portal>
          <Dialog.Overlay className="fixed inset-0 bg-black/50 z-50" />
          <Dialog.Content className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-card p-6 rounded-lg shadow-xl w-full max-w-md z-50">
            <Dialog.Title className="text-lg font-semibold mb-4">
              Selecionar Página da Planilha
            </Dialog.Title>
            
            <div className="space-y-4">
              {selectedLink && sheetInfo[selectedLink]?.sheets.map((sheet, index) => {
                const isSelected = selectedSheet?.link === selectedLink && selectedSheet?.sheet === sheet;
                
                return (
                  <motion.div
                    key={sheet}
                    role="button"
                    tabIndex={0}
                    onClick={() => handleSelectSheet(selectedLink, sheet)}
                    onKeyPress={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        handleSelectSheet(selectedLink, sheet);
                      }
                    }}
                    className={`
                      w-full p-3 text-left rounded-md transition-all duration-200 flex items-center gap-3 cursor-pointer
                      ${isSelected 
                        ? 'bg-neon-blue/10 border-2 border-neon-blue' 
                        : 'bg-secondary/50 hover:bg-secondary/70 border-2 border-transparent'
                      }
                    `}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2, delay: index * 0.05 }}
                  >
                    <Link className={`w-4 h-4 ${isSelected ? 'text-neon-blue' : 'text-neon-purple'}`} />
                    <span className={`font-medium ${isSelected ? 'text-neon-blue' : ''}`}>
                      {sheet}
                    </span>
                    {isSelected && (
                      <span className="ml-auto text-xs bg-neon-blue/20 text-neon-blue px-2 py-1 rounded-full">
                        Selecionada
                      </span>
                    )}
                  </motion.div>
                );
              })}
            </div>

            <div className="flex justify-end gap-2 mt-6">
              <Dialog.Close asChild>
                <button className="px-4 py-2 text-sm rounded-md bg-secondary hover:bg-secondary/80 transition-colors">
                  Cancelar
                </button>
              </Dialog.Close>
            </div>
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>
    </div>
  );
}