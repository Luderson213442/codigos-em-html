import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, NavLink } from 'react-router-dom';
import { motion } from 'framer-motion';
import { LayoutGrid, Menu, Upload, User } from 'lucide-react';
import { FileUpload } from './components/FileUpload';
import { DashboardV1Page } from './pages/DashboardV1Page';
import { LeadData, UserProfile } from './types';
import { UserProfileSelector } from './components/UserProfileSelector';
import { UserDashboard } from './components/UserDashboard';

function App() {
  const [leads, setLeads] = useState<LeadData[]>([]);
  const [showUpload, setShowUpload] = useState<boolean>(true);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [sheetInfo, setSheetInfo] = useState<{ id: string; sheet: string } | null>(null);
  const [userProfiles, setUserProfiles] = useState<UserProfile[]>([]);
  const [selectedProfile, setSelectedProfile] = useState<UserProfile | null>(null);
  const [selectedSheet, setSelectedSheet] = useState<{ link: string; sheet: string } | null>(null);

  const handleFileUpload = async (data: LeadData[], newSheetInfo?: { id: string; sheet: string }) => {
    setLeads(data);
    setShowUpload(false);
    if (newSheetInfo) {
      setSheetInfo(newSheetInfo);
    }
  };

  const handleUserProfilesUpload = (data: UserProfile[]) => {
    setUserProfiles(data);
    if (data.length > 0) {
      setSelectedProfile(data[0]);
    }
    setShowUpload(false);
  };

  const handleSelectLink = async (link: string, sheetName: string) => {
    try {
      if (!link.includes('/spreadsheets/d/')) {
        throw new Error('URL inválida. Por favor, insira uma URL válida do Google Sheets.');
      }

      const matches = link.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
      if (!matches) {
        throw new Error('URL inválida. Não foi possível encontrar o ID da planilha.');
      }

      const id = matches[1];
      const exportUrl = `https://docs.google.com/spreadsheets/d/${id}/export?format=xlsx`;

      const response = await fetch(exportUrl);
      if (!response.ok) {
        throw new Error('Não foi possível acessar a planilha. Verifique se ela está pública.');
      }

      const arrayBuffer = await response.arrayBuffer();
      const XLSX = await import('xlsx');
      const workbook = XLSX.read(arrayBuffer, { type: 'array' });
      
      const sheet = workbook.Sheets[sheetName];
      if (!sheet) {
        throw new Error(`Página "${sheetName}" não encontrada na planilha.`);
      }

      const jsonData = XLSX.utils.sheet_to_json(sheet, {
        header: 1,
        blankrows: false,
        raw: false,
        defval: ''
      });

      if (jsonData.length < 2) {
        throw new Error('A planilha está vazia ou não contém dados suficientes');
      }

      const headers = jsonData[0] as string[];
      const data = jsonData.slice(1).map(row => {
        const obj: any = {};
        headers.forEach((header, index) => {
          obj[header] = (row as any[])[index] || '';
        });
        return obj;
      });

      const FileUpload = await import('./components/FileUpload');
      const processedData = FileUpload.processData(data);
      setLeads(processedData);
      setSheetInfo({ id, sheet: sheetName });
      setSelectedSheet({ link, sheet: sheetName });
    } catch (error) {
      console.error('Error loading spreadsheet:', error);
    }
  };

  const handleUpdate = async () => {
    if (!sheetInfo || !selectedSheet) {
      setShowUpload(true);
      return;
    }

    try {
      const exportUrl = `https://docs.google.com/spreadsheets/d/${sheetInfo.id}/export?format=xlsx`;
      const response = await fetch(exportUrl);
      
      if (!response.ok) {
        throw new Error('Não foi possível acessar a planilha. Verifique se ela está pública.');
      }

      const arrayBuffer = await response.arrayBuffer();
      const XLSX = await import('xlsx');
      const workbook = XLSX.read(arrayBuffer, { type: 'array' });
      
      const sheet = workbook.Sheets[sheetInfo.sheet];
      if (!sheet) {
        throw new Error(`Página "${sheetInfo.sheet}" não encontrada na planilha.`);
      }

      const jsonData = XLSX.utils.sheet_to_json(sheet, {
        header: 1,
        blankrows: false,
        raw: false,
        defval: ''
      });

      if (jsonData.length < 2) {
        throw new Error('A planilha está vazia ou não contém dados suficientes');
      }

      const headers = jsonData[0] as string[];
      const data = jsonData.slice(1).map(row => {
        const obj: any = {};
        headers.forEach((header, index) => {
          obj[header] = (row as any[])[index] || '';
        });
        return obj;
      });

      const FileUpload = await import('./components/FileUpload');
      const processedData = FileUpload.processData(data);
      setLeads(processedData);
    } catch (error) {
      console.error('Error updating data:', error);
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <Router>
      <div className="min-h-screen bg-background text-foreground">
        {/* Mobile Header */}
        <div className="lg:hidden border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container flex h-14 items-center justify-between">
            <div className="flex items-center">
              <button
                onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                className="p-2 hover:bg-secondary rounded-md"
              >
                <Menu className="w-6 h-6" />
              </button>
              <div className="flex items-center ml-2">
                <LayoutGrid className="h-6 w-6 text-neon-purple" />
                <span className={`font-bold text-lg ml-2 transition-opacity duration-300 ${isSidebarOpen ? 'opacity-100' : 'opacity-0'}`}>
                  LeadFlow
                </span>
              </div>
            </div>
            {selectedProfile && (
              <div className="flex items-center gap-3">
                <div className="text-right hidden sm:block">
                  <p className="text-sm font-medium">{selectedProfile.user}</p>
                  <p className="text-xs text-muted-foreground">{selectedProfile.email}</p>
                </div>
                <div className="w-8 h-8 rounded-full bg-neon-purple/20 text-neon-purple flex items-center justify-center text-sm font-medium">
                  {getInitials(selectedProfile.user)}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Desktop Header */}
        <div className="hidden lg:block fixed top-0 right-0 p-4 z-50">
          {selectedProfile && (
            <div className="flex flex-col items-end gap-2">
              <div className="flex items-center gap-3 bg-card/80 backdrop-blur-sm border border-border/40 rounded-lg px-4 py-2">
                <div className="text-right">
                  <p className="text-sm font-medium">{selectedProfile.user}</p>
                  <p className="text-xs text-muted-foreground">{selectedProfile.email}</p>
                </div>
                <div className="w-10 h-10 rounded-full bg-neon-purple/20 text-neon-purple flex items-center justify-center text-sm font-medium">
                  {getInitials(selectedProfile.user)}
                </div>
              </div>
              <UserProfileSelector
                profiles={userProfiles}
                selectedProfile={selectedProfile}
                onSelectProfile={setSelectedProfile}
              />
            </div>
          )}
        </div>

        {/* Sidebar */}
        <div
          className={`
            fixed top-0 left-0 h-full bg-card border-r border-border/40 transition-all duration-300 z-40
            ${isSidebarOpen ? 'w-64' : 'w-0 -translate-x-full lg:translate-x-0 lg:w-20'}
            lg:relative lg:block
          `}
        >
          <div className="p-6 hidden lg:flex lg:items-center">
            <button
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="p-2 hover:bg-secondary rounded-md"
            >
              <Menu className="w-6 h-6" />
            </button>
            <div className="flex items-center ml-2">
              <LayoutGrid className="h-6 w-6 text-neon-purple" />
              <span className={`font-bold text-lg ml-2 transition-opacity duration-300 ${isSidebarOpen ? 'opacity-100' : 'opacity-0 lg:hidden'}`}>
                LeadFlow
              </span>
            </div>
          </div>

          <nav className="mt-6">
            <NavLink
              to="/"
              className={({ isActive }) => `
                flex items-center space-x-2 px-6 py-3 text-sm font-medium transition-colors
                ${isActive ? 'bg-secondary text-foreground' : 'text-muted-foreground hover:text-foreground hover:bg-secondary/50'}
              `}
            >
              <LayoutGrid className="h-5 w-5" />
              <span className={`transition-opacity duration-300 ${isSidebarOpen ? 'opacity-100' : 'opacity-0 lg:hidden'}`}>
                Dashboard
              </span>
            </NavLink>
          </nav>
        </div>

        {/* Main Content */}
        <main className={`transition-all duration-300 ${isSidebarOpen ? 'lg:ml-64' : 'lg:ml-20'}`}>
          {showUpload ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <FileUpload onUpload={handleFileUpload} onUserProfilesUpload={handleUserProfilesUpload} />
            </motion.div>
          ) : (
            <Routes>
              <Route path="/" element={
                <>
                  <div className="mx-[15px] mt-6">
                    <div className="flex items-center justify-between mb-6">
                      <div className="block lg:hidden">
                        <UserProfileSelector
                          profiles={userProfiles}
                          selectedProfile={selectedProfile}
                          onSelectProfile={setSelectedProfile}
                        />
                      </div>
                      <button
                        onClick={() => setShowUpload(true)}
                        className="flex items-center gap-2 px-4 py-2 bg-neon-blue text-background rounded-md hover:opacity-90 transition-opacity"
                      >
                        <Upload className="w-4 h-4" />
                        Novos Dados
                      </button>
                    </div>
                    {selectedProfile && (
                      <UserDashboard
                        profile={selectedProfile}
                        onSelectLink={handleSelectLink}
                        selectedSheet={selectedSheet}
                      />
                    )}
                  </div>
                  {leads.length > 0 && (
                    <DashboardV1Page
                      leads={leads}
                      onUpdate={handleUpdate}
                      hasSheetInfo={!!sheetInfo}
                    />
                  )}
                </>
              } />
            </Routes>
          )}
        </main>
      </div>
    </Router>
  );
}

export default App;