import React, { useState, useMemo, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  LineChartIcon,
  FileText,
  FileCheck,
  Users,
  Settings,
  Filter,
  RefreshCw
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { LeadData } from '../types';
import { DateRangeFilter } from '../components/DateRangeFilter';
import { DateRange } from 'react-day-picker';
import { isWithinInterval, parseISO, startOfDay, endOfDay, format, eachDayOfInterval, subDays, isSameDay } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { EditableMetricCard } from '../components/EditableMetricCard';
import { ColumnSelector, type ColumnConfig } from '../components/ColumnSelector';
import { TagFilter, type TagFilterGroup } from '../components/TagFilter';
import { EditableBanner } from '../components/EditableBanner';
import { AnimatedCounter } from '../components/AnimatedCounter';

interface DashboardV1Props {
  leads: LeadData[];
  onUpdate: () => void;
  hasSheetInfo: boolean;
}

interface MetricConfig {
  title: string;
  tag: string;
}

const INITIAL_COLUMNS: ColumnConfig[] = [
  { field: 'nome', label: 'Nome', visible: true },
  { field: 'empresa', label: 'Empresa', visible: true },
  { field: 'qualidade', label: 'Qualidade', visible: true },
  { field: 'whatsapp', label: 'WhatsApp', visible: false },
  { field: 'email', label: 'E-mail', visible: false },
  { field: 'faturamento', label: 'Faturamento', visible: false },
  { field: 'cargo', label: 'Cargo', visible: false },
  { field: 'motivo', label: 'Motivo', visible: false },
  { field: 'dataHora', label: 'Data e Hora', visible: false },
  { field: 'origem', label: 'Origem', visible: false },
  { field: 'tags', label: 'Tags', visible: true },
];

const isValidDate = (dateStr: string): boolean => {
  try {
    const date = parseISO(dateStr);
    return !isNaN(date.getTime());
  } catch {
    return false;
  }
};

export function DashboardV1Page({ leads, onUpdate, hasSheetInfo }: DashboardV1Props) {
  const [dateRange, setDateRange] = useState<DateRange | undefined>();
  const [metrics, setMetrics] = useState<MetricConfig[]>([
    { title: 'Fluxos Iniciados', tag: 'iniciou_fluxo' },
    { title: 'Forms Abertos', tag: 'abriu_formulario' },
    { title: 'Forms Preenchidos', tag: 'preencheu_formulario' },
  ]);
  const [searchTerm, setSearchTerm] = useState('');
  const [columns, setColumns] = useState<ColumnConfig[]>(INITIAL_COLUMNS);
  const [isColumnSelectorOpen, setIsColumnSelectorOpen] = useState(false);
  const [isTagFilterOpen, setIsTagFilterOpen] = useState(false);
  const [tagFilterGroups, setTagFilterGroups] = useState<TagFilterGroup[]>([]);
  const [tableDateRange, setTableDateRange] = useState<DateRange | undefined>();
  const [bannerConfig, setBannerConfig] = useState({
    title: 'Dashboard de Leads',
    description: 'Acompanhe e gerencie seus leads em tempo real',
    imageUrl: 'https://images.unsplash.com/photo-1639322537228-f710d846310a?auto=format&fit=crop&q=80&w=3276&h=300'
  });
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Auto-refresh interval
  useEffect(() => {
    if (!hasSheetInfo) return;

    const interval = setInterval(() => {
      onUpdate();
    }, 300000); // Refresh every 5 minutes

    return () => clearInterval(interval);
  }, [hasSheetInfo, onUpdate]);

  const allTags = Array.from(
    new Set(
      leads.flatMap(lead => 
        lead.tags.flatMap(tag => tag.split(',').map(t => t.trim()))
      )
    )
  ).filter(Boolean).sort();

  const getLeadTags = (lead: LeadData): string[] => {
    return lead.tags.flatMap(tag => tag.split(',').map(t => t.trim())).filter(Boolean);
  };

  const timeSeriesData = useMemo(() => {
    let startDate = dateRange?.from;
    let endDate = dateRange?.to;

    if (!startDate || !endDate) {
      const validDates = leads
        .map(lead => lead.dataHora)
        .filter(isValidDate)
        .map(dateStr => parseISO(dateStr));

      if (validDates.length > 0) {
        startDate = new Date(Math.min(...validDates.map(d => d.getTime())));
        endDate = new Date(Math.max(...validDates.map(d => d.getTime())));
      } else {
        endDate = new Date();
        startDate = subDays(endDate, 30);
      }
    }

    const isSingleDay = startDate && endDate && isSameDay(startDate, endDate);
    const dateCountMap = new Map<string, number>();
    
    if (isSingleDay) {
      for (let hour = 0; hour < 24; hour++) {
        const hourStr = hour.toString().padStart(2, '0');
        dateCountMap.set(hourStr, 0);
      }

      leads.forEach(lead => {
        if (lead.dataHora && isValidDate(lead.dataHora)) {
          const leadDate = parseISO(lead.dataHora);
          if (isSameDay(leadDate, startDate)) {
            const hour = leadDate.getHours().toString().padStart(2, '0');
            dateCountMap.set(hour, (dateCountMap.get(hour) || 0) + 1);
          }
        }
      });

      return Array.from(dateCountMap.entries())
        .map(([hour, count]) => ({
          date: `${hour}:00`,
          fullDate: hour,
          'Total de Leads': count
        }))
        .sort((a, b) => a.fullDate.localeCompare(b.fullDate));
    } else {
      eachDayOfInterval({
        start: startOfDay(startDate),
        end: endOfDay(endDate)
      }).forEach(date => {
        const dateStr = format(date, 'yyyy-MM-dd');
        dateCountMap.set(dateStr, 0);
      });

      leads.forEach(lead => {
        if (lead.dataHora && isValidDate(lead.dataHora)) {
          const leadDate = parseISO(lead.dataHora);
          if (isWithinInterval(leadDate, { start: startOfDay(startDate), end: endOfDay(endDate) })) {
            const dateStr = format(leadDate, 'yyyy-MM-dd');
            dateCountMap.set(dateStr, (dateCountMap.get(dateStr) || 0) + 1);
          }
        }
      });

      return Array.from(dateCountMap.entries())
        .map(([date, count]) => ({
          date: format(parseISO(date), 'dd/MM', { locale: ptBR }),
          fullDate: date,
          'Total de Leads': count
        }))
        .sort((a, b) => a.fullDate.localeCompare(b.fullDate));
    }
  }, [leads, dateRange]);

  const totalLeadsInPeriod = timeSeriesData.reduce((sum, data) => sum + data['Total de Leads'], 0);

  const handleMetricUpdate = (index: number, newTitle: string, newTag: string) => {
    const newMetrics = [...metrics];
    newMetrics[index] = { title: newTitle, tag: newTag };
    setMetrics(newMetrics);
  };

  const handleColumnToggle = (field: keyof LeadData) => {
    setColumns(prev =>
      prev.map(col =>
        col.field === field ? { ...col, visible: !col.visible } : col
      )
    );
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      await onUpdate();
    } finally {
      setIsRefreshing(false);
    }
  };

  const filteredLeads = leads.filter((lead) => {
    const matchesSearch = !searchTerm || 
      lead.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.empresa.toLowerCase().includes(searchTerm.toLowerCase());
    
    const leadTags = getLeadTags(lead);
    
    const matchesTags = tagFilterGroups.length === 0 || tagFilterGroups.some(group => {
      const groupMatches = group.conditions.every(condition => {
        const hasTag = leadTags.includes(condition.tag);
        return condition.type === 'is' ? hasTag : !hasTag;
      });
      
      if (group.operator === 'OR') {
        return group.conditions.some(condition => {
          const hasTag = leadTags.includes(condition.tag);
          return condition.type === 'is' ? hasTag : !hasTag;
        });
      }
      
      return groupMatches;
    });

    const matchesDateRange = !tableDateRange?.from || !tableDateRange?.to || (
      lead.dataHora && 
      isValidDate(lead.dataHora) && 
      isWithinInterval(
        parseISO(lead.dataHora),
        { start: startOfDay(tableDateRange.from), end: endOfDay(tableDateRange.to) }
      )
    );
    
    return matchesSearch && matchesTags && matchesDateRange;
  });

  const visibleColumns = columns.filter(col => col.visible);

  const renderCellContent = (lead: LeadData, column: ColumnConfig) => {
    if (column.field === 'qualidade') {
      return (
        <span
          className={`px-2 py-1 rounded-full text-xs ${
            lead.qualidade === 'Alta'
              ? 'bg-neon-green/20 text-neon-green'
              : lead.qualidade === 'Média'
              ? 'bg-neon-blue/20 text-neon-blue'
              : 'bg-neon-purple/20 text-neon-purple'
          }`}
        >
          {lead.qualidade}
        </span>
      );
    }
    
    if (column.field === 'tags') {
      const tags = getLeadTags(lead);
      if (tags.length === 0) return null;
      
      return (
        <div className="flex flex-wrap gap-1">
          {tags.map((tag, index) => (
            <span
              key={`${lead.id}-${tag}-${index}`}
              className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs ${
                tagFilterGroups.some(group =>
                  group.conditions.some(condition =>
                    condition.tag === tag &&
                    ((condition.type === 'is' && tags.includes(tag)) ||
                     (condition.type === 'isNot' && !tags.includes(tag)))
                  )
                )
                  ? 'bg-neon-green/20 text-neon-green'
                  : 'bg-gray-600/20 text-gray-400'
              }`}
            >
              {tag}
            </span>
          ))}
        </div>
      );
    }

    if (column.field === 'dataHora' && lead.dataHora) {
      try {
        return format(parseISO(lead.dataHora), 'dd/MM/yyyy HH:mm', { locale: ptBR });
      } catch {
        return lead.dataHora;
      }
    }
    
    return lead[column.field];
  };

  return (
    <div className="mx-[15px] space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <EditableBanner
          title={bannerConfig.title}
          description={bannerConfig.description}
          imageUrl={bannerConfig.imageUrl}
          onUpdate={(newTitle, newDescription, newImageUrl) => {
            setBannerConfig({
              title: newTitle,
              description: newDescription,
              imageUrl: newImageUrl
            });
          }}
        />
      </motion.div>

      <motion.div
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <EditableMetricCard
          title="Total de Leads"
          icon={<Users className="w-8 h-8" />}
          iconColor="text-neon-purple"
          tag=""
          leads={leads}
          onUpdate={() => {}}
          isEditable={false}
          allTags={allTags}
        />

        {metrics.map((metric, index) => {
          const Icon = index === 0 ? LineChartIcon : index === 1 ? FileText : FileCheck;
          const color = index === 0 ? 'text-neon-blue' : index === 1 ? 'text-neon-green' : 'text-neon-purple';
          
          return (
            <EditableMetricCard
              key={index}
              title={metric.title}
              icon={<Icon className="w-8 h-8" />}
              iconColor={color}
              tag={metric.tag}
              leads={leads}
              onUpdate={(newTitle, newTag) => handleMetricUpdate(index, newTitle, newTag)}
              allTags={allTags}
            />
          );
        })}
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <div className="bg-card rounded-lg p-6 border border-border/50">
          <div className="mb-4">
            <h3 className="text-lg font-semibold mb-2">Filtrar por data</h3>
            <div className="w-[40%]">
              <DateRangeFilter
                dateRange={dateRange}
                onDateRangeChange={setDateRange}
                placeholder="Selecionar período personalizado"
                presets={[
                  { label: 'Hoje', value: 'today' },
                  { label: '7 dias', value: '7days' },
                  { label: '30 dias', value: '30days' },
                  { label: 'Tempo todo', value: 'all' }
                ]}
              />
            </div>
          </div>

          <div className="flex gap-6">
            <div className="w-[65%] bg-card rounded-lg p-6 border border-border/50">
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={timeSeriesData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis
                      dataKey="date"
                      stroke="#6B7280"
                      fontSize={12}
                      tickLine={false}
                    />
                    <YAxis
                      stroke="#6B7280"
                      fontSize={12}
                      tickLine={false}
                      allowDecimals={false}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'rgba(17, 24, 39, 0.8)',
                        border: 'none',
                        borderRadius: '4px',
                        fontSize: '12px',
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="Total de Leads"
                      stroke="#8000ff"
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="w-[35%] bg-card rounded-lg p-6 border border-border/50 flex flex-col items-center justify-center">
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Total de Leads no Período</p>
                <AnimatedCounter 
                  value={totalLeadsInPeriod} 
                  className="text-5xl font-bold text-neon-purple mt-2 block"
                />
              </div>
              
              {dateRange?.from && dateRange?.to && (
                <div className="text-center mt-6">
                  <p className="text-sm text-muted-foreground">Período Selecionado</p>
                  <p className="text-lg font-medium text-neon-green mt-2">
                    {format(dateRange.from, 'dd/MM/yyyy', { locale: ptBR })} - {format(dateRange.to, 'dd/MM/yyyy', { locale: ptBR })}
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
        className="space-y-4"
      >
        <div className="flex flex-wrap gap-4">
          <input
            type="text"
            placeholder="Pesquisar leads..."
            className="px-4 py-2 bg-secondary rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <button
            onClick={() => setIsColumnSelectorOpen(true)}
            style={{ backgroundColor: '#0d6fe8', color: '#09090b' }}
            className="px-4 py-2 rounded-md hover:opacity-90 transition-opacity flex items-center gap-2"
          >
            <Settings className="w-4 h-4" />
            Escolher Campos
          </button>
          <button
            onClick={() => setIsTagFilterOpen(true)}
            className="px-4 py-2 bg-secondary rounded-md hover:bg-secondary/80 transition-colors flex items-center gap-2"
          >
            <Filter className="w-4 h-4" />
            Filtro Avançado de Tags
            {tagFilterGroups.length > 0 && (
              <span className="px-2 py-0.5 text-xs bg-neon-blue/20 text-neon-blue rounded-full">
                {tagFilterGroups.reduce((acc, group) => acc + group.conditions.length, 0)}
              </span>
            )}
          </button>
          <DateRangeFilter
            dateRange={tableDateRange}
            onDateRangeChange={setTableDateRange}
            placeholder="Filtrar tabela por data"
            presets={[
              { label: 'Hoje', value: 'today' },
              { label: '7 dias', value: '7days' },
              { label: '30 dias', value: '30days' },
              { label: 'Tempo todo', value: 'all' }
            ]}
          />
          {hasSheetInfo && (
            <button
              onClick={handleRefresh}
              disabled={isRefreshing}
              className="px-4 py-2 bg-neon-green text-background rounded-md hover:opacity-90 transition-opacity flex items-center gap-2 disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
              {isRefreshing ? 'Atualizando...' : 'Atualizar Dados'}
            </button>
          )}
          {(tagFilterGroups.length > 0 || tableDateRange) && (
            <button
              onClick={() => {
                setTagFilterGroups([]);
                setTableDateRange(undefined);
              }}
              className="px-3 py-1 text-sm text-destructive hover:text-destructive/80 transition-colors"
            >
              Limpar Filtros
            </button>
          )}
        </div>

        <div className="bg-card rounded-lg border border-border/50 overflow-hidden">
          <div className="h-[325px] overflow-y-auto scrollbar-custom">
            <table className="w-full">
              <thead className="sticky top-0 bg-card border-b border-border/50 z-10">
                <tr>
                  {visibleColumns.map(column => (
                    <th key={column.field} className="p-4 text-left bg-card">
                      {column.label}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filteredLeads.map((lead) => (
                  <motion.tr
                    key={lead.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.3 }}
                    className="border-b border-border/50 hover:bg-muted/50"
                  >
                    {visibleColumns.map(column => (
                      <td key={column.field} className="p-4">
                        {renderCellContent(lead, column)}
                      </td>
                    ))}
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <ColumnSelector
          columns={columns}
          onColumnToggle={handleColumnToggle}
          isOpen={isColumnSelectorOpen}
          onClose={() => setIsColumnSelectorOpen(false)}
        />

        <TagFilter
          allTags={allTags}
          filterGroups={tagFilterGroups}
          onUpdateFilters={setTagFilterGroups}
          isOpen={isTagFilterOpen}
          onClose={() => setIsTagFilterOpen(false)}
        />
      </motion.div>
    </div>
  );
}