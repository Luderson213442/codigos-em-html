export interface LeadData {
  id: string;
  nome: string;
  whatsapp: string;
  email: string;
  empresa: string;
  faturamento: string;
  cargo: string;
  motivo: string;
  qualidade: 'Baixa' | 'Média' | 'Alta';
  dataHora: string;
  tags: string[];
  origem?: string;
}

export interface ChartData {
  name: string;
  value: number;
}

export interface UserProfile {
  user: string;
  email: string;
  senha: string;
  links: string[];
}